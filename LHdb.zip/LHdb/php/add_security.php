<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$id=$_POST["id"];
$name=$_POST["name"];
$passwd=$_POST["passwd"];
$phoneno=$_POST["phoneno"];

$sql = "INSERT INTO Security VALUES ('$id', '$name', '$passwd', '$phoneno')"; 
if ($conn->query($sql) === TRUE)
{
	echo "Succesfull";
}
else
	echo "failed";

$conn->close();
?>