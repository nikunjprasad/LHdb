<?php 
session_start();
if(session_id()=='' || !isset($_SESSION['login']))
{
  header("Location:/code/login.php");
}
?>

<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$rollno=$_SESSION["st_roll"];
$securityID=$_SESSION["login"];
//echo "5 latest entries";
date_default_timezone_set('Asia/Kolkata');
$sql= "SELECT * FROM St_Status WHERE '$rollno'=Student_RollNo";
$timestamp= date("Y-m-d H:i:s");
$result = $conn->query($sql);
if($result->num_rows > 0)
    {
        while($row=$result->fetch_assoc()) 
        {

      
          $s1="UPDATE St_Status SET Status='0' WHERE '$rollno'=Student_RollNo";
          if($conn->query($s1) === TRUE) 
          {
            //echo "updated";
          }   
          else;
          //echo "update failed";
        }

        $s3= "INSERT INTO LateReg (Student_RollNo,Security_SecurityID,TimeOut) VALUES ('$rollno','$securityID',now())";
        if($conn->query($s3) === TRUE);
        
        else;
          //echo "update failed";
         
        
        header("Location:/code/latelogin.php");
    }
else
{
     echo '<script> alert("Wrong roll no")</script>';   
     header("Location:/code/latelogin.php");  
 }       
$conn->close();
?>
