<?php 
session_start();
if(session_id()=='' || !isset($_SESSION['login']))
{
  header("Location:/code/login.php");
}
?>

<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);
date_default_timezone_set('Asia/Kolkata');
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$rollno=$_SESSION["st_roll"];
$sql= "SELECT * FROM St_Status WHERE '$rollno'=Student_RollNo";
$result = $conn->query($sql);
if($result->num_rows > 0)
    {
        while($row=$result->fetch_assoc()) 
        {

      
          if(date('H:i:s')>'21:00:00')
          {
           $s4= "UPDATE St_Status SET Warning=Warning+1 WHERE '$rollno'=Student_RollNo"; 
           if($conn->query($s4) === TRUE);
           else;
          //echo "update failed";
          }
          $s1="UPDATE St_Status SET Status='1' WHERE '$rollno'=Student_RollNo";
          if($conn->query($s1) === TRUE) ;
          else;
          //echo "update failed";
        }

        $s2= "SELECT * FROM LateReg WHERE '$rollno'=Student_RollNo AND TimeIn IS NULL";
        $r2= $conn->query($s2);
        if($r2->num_rows > 0)
        { 
        while($row=$r2->fetch_assoc()) 
        {  
        $s3= "UPDATE LateReg SET TimeIn=now() WHERE '$rollno'=Student_RollNo AND TimeIn IS NULL";
        if($conn->query($s3) === TRUE);
        else;
          //echo "update failed";
        }  
        }
        header("Location:/code/latelogin.php");
    }
else
    echo "Sorry, you have typed in wrong roll number!";    
        
$conn->close();
?>
