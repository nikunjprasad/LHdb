<?php 
session_start();
if(session_id()=='' || !isset($_SESSION['login']))
{
  header("Location:/code/login.php");
}
?>

<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);
date_default_timezone_set('Asia/Kolkata');
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$rollno=$_SESSION["st_roll"];
$flag=0;
$s2= "SELECT * FROM Movement WHERE '$rollno'=Student_RollNo AND TimeIn IS NULL";
        $r2= $conn->query($s2);
        if($r2->num_rows > 0)
        { 
        while($row=$r2->fetch_assoc()) 
        {  
          
        $s3= "UPDATE Movement SET TimeIn=now() WHERE '$rollno'=Student_RollNo AND TimeIn IS NULL";
        if($conn->query($s3) === TRUE)
        {
          //echo "updated";
          if(!empty($row['LatePTime']) and date('h:i:s')>$row['LatePTime'])
            $flag=1;
        }
        else;
          //echo "update failed";
        }
        } 

        
$sql= "SELECT * FROM St_Status WHERE '$rollno'=Student_RollNo";
$result = $conn->query($sql);
if($result->num_rows > 0)
    {
        while($row=$result->fetch_assoc()) 
        {

           if(date('H:i:s')>'19:15:00' or $flag=1)
          {
           $s4= "UPDATE St_Status SET Warning=Warning+1 WHERE '$rollno'=Student_RollNo"; 
           if($conn->query($s4) === TRUE)
           {
          //echo "updated";
           }
           else;
          //echo "update failed";
          }
          $s1="UPDATE St_Status SET Status='1' WHERE '$rollno'=Student_RollNo";
          if($conn->query($s1) === TRUE) 
          {
            //echo "updated";
          }   
          else;
          //echo "update failed";
        }
        echo '<script> alert("You have been signed in.")</script>';
        echo '<script> window.location = "/code/normallogin.php" </script>';
        exit();
    }
else
    echo "Sorry, you have typed in wrong roll number!";    
        
$conn->close();
?>
