<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$rollno=$_POST["rollno"];
$name=$_POST["name"];
$roomno=$_POST["roomno"];
$blockno=$_POST["blockno"];
$phoneno=$_POST["phoneno"];
$homeddr=$_POST["homeaddr"];
$parentsno=$_POST["parentsno"];

$sql = "INSERT INTO Student VALUES ('$rollno', '$name', '$roomno','$blockno','$phoneno', '$homeaddr', 'parentsno')"; 
if ($conn->query($sql) === TRUE)
{
	echo "Succesfull";
}
else
	echo "failed";

$conn->close();
?>