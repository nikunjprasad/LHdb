<?php 
session_start();
if(session_id()=='' || !isset($_SESSION['login']))
{
  header("Location:/code/login.php");
}
?>

<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);
date_default_timezone_set('Asia/Kolkata');
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$rollno=$_SESSION["st_roll"];
$securityID=$_SESSION["login"];
$place=$_POST['place'];
//echo "5 latest entries";
$flag=0;
$sql= "SELECT * FROM St_Status WHERE '$rollno'=Student_RollNo";
//$timestamp=now();
$result = $conn->query($sql);
if($result->num_rows > 0)
    {
        if($row=$result->fetch_assoc()) 
        {
          
          if(date('H:i:s')>'19:00:00')
          {
            echo '<script> alert("Please Sign Out in the Late register")</script>';
            echo '<script> window.location = "/code/latelogin.php" </script>';
            //header("Location:/code/normallogin.php");
            exit();
          }
          if(date('H:i:s')<'06:00:00')
          {   
              
              $sqlp = "SELECT EarlyPTime from permission where '$rollno'=Student_RollNo";
              $resultp = $conn->query($sqlp);
              if($rowp=$resultp->fetch_assoc())
              {
                //echo date("d/m/y", strtotime($rowp['EarlyPTime'])).date("d/m/y");
                //echo date("H:i:s", strtotime($rowp['EarlyPTime'])).date("H:i:s");
                  die();
                if(((date("d/m/y", strtotime($rowp['EarlyPTime'])))!=date("d/m/y")) || (date("H:i:s", strtotime($rowp['EarlyPTime']>date("H:i:s")))))
                {
                  echo '<script> alert("Too early to sign out! Permission denied.")</script>';
                  echo '<script> window.location = "/code/normallogin.php" </script>';
                  exit();
                }
              }
              else
              {
                echo '<script> alert("Too early to sign out! Permission denied.")</script>';
               echo '<script> window.location = "/code/normallogin.php" </script>';
                exit();
              }
          } 

          $s1="UPDATE St_Status SET Status='0' WHERE '$rollno'=Student_RollNo";
          if($conn->query($s1) === TRUE) ;   

          $s2="INSERT INTO Movement (Student_RollNo,Security_SecurityID,Place,TimeOut) VALUES ('$rollno','$securityID','$place',now())";
          if($conn->query($s2) === TRUE){
            echo '<script> alert("You have been signed out.")</script>';
            echo '<script> window.location = "/code/normallogin.php" </script>';
            exit();
          }
          header("Location:/code/normallogin.php");
        }
        }
else
    echo '<script> alert("Wrong roll no")</script>';    
    //echo '<script> alert("Wrong roll no")</script>';    
$conn->close();
?>
