<?php 
session_start();
if(session_id()=='' || !isset($_SESSION['login']))
{
  header("Location:/code/login.php");
}
?>

<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id= $_SESSION["login"];
$opwd= $_POST["opwd"];
$passwd=$_POST["passwd"];

$s1= "SELECT * FROM Security where Password='$opwd' AND SecurityID='$id'";
$result= $conn->query($s1);
if($result->num_rows >0)
{
	while($row= $result->fetch_assoc())
	{		
		$sql = "UPDATE Security SET Password='$passwd'WHERE SecurityID='$id'"; 
	}	
$sq1 = "UPDATE Security SET Password='$passwd'WHERE SecurityID='$id'";
if ($conn->query($sq1) === TRUE)
{
	echo '<script> alert("Successfully updated")</script>';
	echo '<script> window.location = "/code/security.php" </script>';
}
else {
	echo '<script> alert("Update failed. Try again.")</script>';
	echo '<script> window.location = "/code/php/changepass.php" </script>'; }
}
else
{ echo '<script> alert("Incorrect password. Try again")</script>';
	echo '<script> window.location = "/code/php/changepass.php" </script>'; }

$conn->close();
?>