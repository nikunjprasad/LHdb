<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$rollno=$_POST["rollno"];
$name=$_POST["name"];
$roomno=$_POST["roomno"];
$blockno=$_POST["blockno"];
$phoneno=$_POST["phoneno"];
$homeddr=$_POST["homeaddr"];
$parentsno=$_POST["parentsno"];

$s1= "SELECT * FROM Student";
$result= $conn->query($s1);
if($result->num_rows >0)
{
	while($row= $result->fetch_assoc())
	{		
		$sql = "UPDATE Student SET Name='$name', RoomNo='$roomno', BlockNo='$blockno', PhoneNo='$phoneno', HomeAddr='$homeaddr', ParentsNo='$parentsno' WHERE RollNo='$rollno'"; 
	}	
}
$sq1 = "UPDATE Student SET Name='$name', RoomNo='$roomno', BlockNo='$blockno', PhoneNo='$phoneno', HomeAddr='$homeaddr', ParentsNo='$parentsno' WHERE RollNo='$rollno'";
if ($conn->query($sq1) === TRUE)
{
	echo "Succesfull";
}
else
	echo "failed";


$conn->close();
?>