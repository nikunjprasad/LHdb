<?php 
session_start();
if(session_id()=='' || !isset($_SESSION['loginw']))
{
  header("Location:/code/login.php");
}
?>

<?php 
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

//echo "yo";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$roll=$_POST["roll"];
//echo $rollno;

$s1="SELECT * FROM permission where Student_RollNo='$roll'";
$result= $conn->query($s1);
if($result->num_rows > 0)
{
	while($row= $result->fetch_assoc())
	{
		//$name= $row["Name"];
	      //  $roll= $row["Student_RollNo"];
		$ep= $row["EarlyPTime"];
		$lp= $row["LatePTime"];
		//$phone= $row["PhoneNo"];
		//$block= $row["BlockNo"];
		//$pno = $row["ParentsNo"];	

echo $row["EarlyPTime"];
	}
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    
  <title>Warden</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/2C6C420E-90CE-A447-AA49-E4075F026DCE/main.js" charset="UTF-8"></script><link rel="stylesheet" crossorigin="anonymous" href="https://gc.kis.v2.scr.kaspersky-labs.com/ECD620F5704E-94AA-744A-EC09-E024C6C2/abn/main.css"/><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   
    <style>
        .leftmenu{
            text-align: left;
            z-index:1;
            left:0;
            line-height:80 px;
            margin: auto;
            margin-top:-100 px;
            position: absolute;
            top:45%;
            width: 100%;
            font-size: 20px;
        }
        #rectangle{
            width:370px;
            height:1100px;
            background-color: aqua;
            z-index: -1;
        }   
        
        .nav{
            font-size: 18px !important;
            margin-top: 10px !important;
        }
        
        #container{
            z-index:1;
            left:0;
            line-height:80 px;
            margin: auto;
            /*margin-top:10 px;*/
            position:absolute;
            top:25%;
            width: 45%;
            margin-left: 550px;
           
            
        }
        button {
        margin-left: 150px;
    background-color: #010001;
    color: white;
    padding: 14px 20px;
    /*margin: 8px auto;*/
    border: none;
    cursor: pointer;
    width: 7%;
    text-align: center;
   
}
        body{
            text-align: center;
            z-index: 0;
        }
        
        
    </style>
</head>
<body>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <!--<div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div> -->
    <ul class="nav navbar-nav">
      <!-- <li class="active"><a href="#">Home</a></li> -->
      <li><a href="warden.php"><span class="glyphicon glyphicon-home"></span><b> Home</b></a></li>                <!--change this to security.html -->
      
       <li class="dropdown">
           <a class="dropdown-toggle" data-toggle="dropdown" href="#"><b>Add</b>
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
            <li><a href="addstudent.php">Student</a></li>
            <li><a href="addsecurity.php">Security</a></li>
            
        </ul>
      </li>
        
        
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" style="color: white" href="#">Modify
        <span class="caret"></span></a>
    
        <ul class="dropdown-menu">
            <li><a href="modifystud.php"><b>Student</b></a></li>
          <li><a href="modifyperm.php">Permission</a></li>
            
        </ul>
   
      </li>
      
        
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">View
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
            <li><a href="viewstud.php">Student</a></li>
          <li><a href="viewsecurity.php">Security</a></li>
            <li><a href="viewwarden.php">Warden</a></li>
        </ul>
      </li>
        
       
        
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Student Status
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="wnormalreg.php">Normal Register</a></li>
          <li><a href="wlatereg.php">Late Register</a></li>
          
        </ul>
      </li>
        
    </ul>

	

    <ul class="nav navbar-nav navbar-right">
	<p class="navbar-text"><span class="glyphicon glyphicon-user"></span> 
  <?php 
          $id=$_SESSION['loginw'];
          $sql= "SELECT Name FROM Warden WHERE '$id'=WardenID";
          $result = $conn->query($sql);
          $row=$result->fetch_assoc();
          echo $row["Name"]; ?></p>
      <li><a href="#"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
    </ul>
  </div>
</nav>
  <div class="leftmenu">
  <div class="uname">
      <label><b><p>Roll No</p></b></label>
  <form action="modifyperm1.php" method="POST" enctype="multipart/form-data">
    <input type="text" name="roll" value="<?php echo  $roll; ?>"/>
  </div>
  <div class="Go">
  <button type="submit">Go</button>
  </form>
  <!--<p>A navigation bar is a navigation header that is placed at the top of the page.</p> -->
    </div>
    
    <div id="rectangle"></div>
    
<div id="container">
  

 <h1>Modify student details</h1><br>
    <form action="malini/modify_earlyptime.php" method="POST" enctype="multipart/form-data">
    
      <pre><span class="inner-pre" style="font-size:20px; font-family:monospace; ">
  <b>     Roll No        <input type="text" name="roll" value="<?php echo  $roll; ?>"/ readonly><br><br>
       EarlyPT        <input name="earlyptime" type="text" placeholder='00-00-0000 00:00:00'/><br><br>  
       LatePT         <input name="lateptime" type="text" placeholder='00-00-0000 00:00:00'/><br><br>

</b>
                      <br>                      <input type="submit" name="save" value="Save Data" size="25px">
                
               </span> </pre> </form>
  <!--<p>A navigation bar is a navigation header that is placed at the top of the page.</p> -->
  <?php
  $conn->close();
?>
</div> 
<script>
    function displayform(){
        document.getElementById("container").style.display="block";
    }
    </script>
</body>
</html>
