<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$id=$_POST["id"];
$name=$_POST["name"];
$passwd=$_POST["passwd"];
$phoneno=$_POST["mobile"];
$gate=$_POST["gate"];

//echo $name;

$sql = "INSERT INTO Security VALUES ('$id', '$name', '$passwd', '$phoneno','$gate')"; 
if ($conn->query($sql) === TRUE)
{
	
	echo '<script> alert("Successfully inserted")</script>';
	echo '<script> window.location = "/code/warden/addsecurity.php" </script>';
}
else
	{echo '<script> alert("Failed")</script>';
	echo '<script> window.location = "/code/warden/addsecurity.php" </script>';}

$conn->close();
?>
