<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$rollno=$_POST["rollno"];

$sql = "SELECT * FROM Student WHERE RollNo='$rollno'"; 
$result = $conn->query($sql);
if($result->num_rows > 0)
{
	echo "<table>"; 
	while($row=$result->fetch_assoc())
	{  
		echo "<tr><td>" . $row['RollNo'] . "</td><td>" . $row['Name'] . "</td></tr>". $row['RoomNo'] . "</td></tr>". $row['BlockNo'] . "</td></tr>". $row['PhoneNo'] . "</td></tr>". $row['HomeAddr'] . "</td></tr>". $row['ParentsNo'] . "</td></tr>";  
	}
	echo "</table>"; 
}
else
 echo "Record does not exist";

$conn->close();
?>