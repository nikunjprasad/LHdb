<?php 
session_start();
if(session_id()=='' || !isset($_SESSION['loginw']))
{
  header("Location:/code/login.php");
}
?>

<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id=$_SESSION["loginw"];
$opwd=$_POST["opwd"];
$passwd=$_POST["passwd"];
//echo $opwd;

$s1= "SELECT * FROM Warden WHERE Password='$opwd' AND WardenID='$id'";
$result= $conn->query($s1);
if($result->num_rows >0)
{
	//echo $result["Name"];
	if($row= $result->fetch_assoc())
	{		
		$sql = "UPDATE Warden SET Password='$passwd' WHERE WardenID='$id'"; 
	}	

$sq1 = "UPDATE Warden SET Password='$passwd' WHERE WardenID='$id'";
if ($conn->query($sq1) === TRUE)
{
	echo '<script> alert("Successfully updated")</script>';
	echo '<script> window.location = "/code/warden/warden.php" </script>';
}
else {
	echo '<script> alert("Update failed. Try again.")</script>';
	echo '<script> window.location = "/code/warden/malini/changepassw.php" </script>'; }
}
else
{ echo '<script> alert("Incorrect password. Try again")</script>';
	echo '<script> window.location = "/code/warden/malini/changepassw.php" </script>'; }

$conn->close();
?>