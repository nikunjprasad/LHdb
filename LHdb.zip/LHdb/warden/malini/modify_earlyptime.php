<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



$rollno=$_POST["roll"];
$earlyptime= $_POST["earlyptime"];
$lateptime= $_POST["lateptime"];
//echo $rollno . " " . $earlyptime . " " . $lateptime;
$s1= "SELECT * FROM permission where Student_RollNo='$rollno'";
$result= $conn->query($s1);
if($result->num_rows >0)
{
	
$sq1 = "UPDATE permission SET EarlyPTime='$earlyptime', LatePTime='$lateptime' WHERE Student_RollNo='$rollno'"; 
if ($conn->query($sq1) === TRUE)
{      
        echo '<script> alert("Successfully updated")</script>';
		echo '<script> window.location = "/code/warden/modifyperm.php" </script>';
}
else{
	echo '<script> alert("Update failed. Try again")</script>';
	echo '<script> window.location = "/code/warden/modifyperm.php" </script>';
}

}
else 
{
	$s2= "INSERT INTO permission (Student_RollNo,EarlyPTime,LatePTime) VALUES ('$rollno','$earlyptime','$lateptime')";
	if ($conn->query($s2) === TRUE)
{

	//header('location:/warden/success.html');
	echo '<script> alert("Successfully updated")</script>';
	echo '<script> window.location = "/code/warden/modifyperm.php" </script>';
}

else
{
	echo '<script> alert("Update failed. Try again")</script>';
	echo '<script> window.location = "/code/warden/modifyperm.php" </script>';

}
}
$conn->close();
?>
