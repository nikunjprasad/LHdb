<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$rollno=$_POST["roll"];

//echo $rollno;

$name=$_POST["name"];
$roomno=$_POST["roomno"];
$blockno=$_POST["block"];
$phoneno=$_POST["mobile"];
$homeaddr=$_POST["adr"];
$parentsno=$_POST["parent"];

/*echo $name;
echo $roomno;
echo $blockno;
echo $phoneno;
echo $homeaddr;*/

$s1= "SELECT * FROM Student";
$result= $conn->query($s1);
if($result->num_rows >0)
{
	while($row= $result->fetch_assoc())
	{		
		$sql = "UPDATE Student SET Name='$name', RoomNo='$roomno', BlockNo='$blockno', PhoneNo='$phoneno', HomeAddr='$homeaddr', ParentsNo='$parentsno' WHERE RollNo='$rollno'"; 
	}	
}
$sq1 = "UPDATE Student SET Name='$name', RoomNo='$roomno', BlockNo='$blockno', PhoneNo='$phoneno', HomeAddr='$homeaddr', ParentsNo='$parentsno' WHERE RollNo='$rollno'";
if ($conn->query($sq1) === TRUE)
{
    echo '<script> alert("Successfully updated")</script>';
	echo '<script> window.location = "/code/warden/modifystud.php" </script>';
}
else
{
	echo '<script> alert("Update failed. Try again")</script>';
	echo '<script> window.location = "/code/warden/modifystud.php" </script>';
}


$conn->close();
?>
