<?php
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$rollno=$_POST["roll"];
$name=$_POST["name"];
$roomno=$_POST["roomno"];
$blockno=$_POST["block"];
$phoneno=$_POST["mobile"];
$homeaddr=$_POST["addr"];
$parentsno=$_POST["parent"];

$sql = "INSERT INTO Student VALUES ('$rollno', '$name', '$roomno','$blockno','$phoneno', '$homeaddr', '$parentsno')"; 
if ($conn->query($sql) === TRUE)
{
	$sql1 = "INSERT INTO St_status (Student_RollNo,Warning,Status) VALUES ('$rollno',0,'1')"; 
if ($conn->query($sql1) === TRUE)
{
	echo '<script> alert("Successfully inserted")</script>';
	echo '<script> window.location = "/code/warden/addstudent.php" </script>';
}

else
	{echo '<script> alert("Failed")</script>';
	echo '<script> window.location = "/code/warden/addstudent.php" </script>';}
}
else
	{echo '<script> alert("Failed")</script>';
	echo '<script> window.location = "/code/warden/addstudent.php" </script>';}

$conn->close();
?>
