 <?php 
session_start();
if(session_id()=='' || !isset($_SESSION['loginw']))
{
  header("Location:/code/login.php");
}
?>
<?php

$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
  <title>Warden</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/2C6C420E-90CE-A447-AA49-E4075F026DCE/main.js" charset="UTF-8"></script><link rel="stylesheet" crossorigin="anonymous" href="https://gc.kis.v2.scr.kaspersky-labs.com/ECD620F5704E-94AA-744A-EC09-E024C6C2/abn/main.css"/><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
   <link rel="stylesheet" href="../css/sidecolorstyle.css">
    
    
    <style>
    /*    .leftmenu{
            text-align: left;
            z-index:1;
            left:0;
            line-height:80 px;
            margin: auto;
            margin-top:-100 px;
            position: absolute;
            top:45%;
            width: 100%;
            font-size: 20px;
        }
        #rectangle{
            width:370px;
            height:1100px;
            background-color: aqua;
            z-index: -1;
        }   
        
        .nav{
            font-size: 18px !important;
            margin-top: 10px !important;
        }
        
        button {
        margin-left: 150px;
    background-color: #010001;
    color: white;
    padding: 14px 20px;
    /*margin: 8px auto;
    border: none;
    cursor: pointer;
    width: 7%;
    text-align: center;
   
}
        body{
            text-align: center;
            z-index: 0;
        } */
        .inner-pre input[type=text]{
      width: 50%;
    }
        
    </style>
</head>
<body>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <!--<div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div> -->
    <ul class="nav navbar-nav">
      <!-- <li class="active"><a href="#">Home</a></li> -->
      <li><a href="warden.php"><span class="glyphicon glyphicon-home"></span><b> Home</b></a></li>                <!--change this to security.html -->
      
       <li class="dropdown">
           <a class="dropdown-toggle" data-toggle="dropdown" href="#"><b>Add</b>
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
            <li><a href="addstudent.php">Student</a></li>
            <li><a href="addsecurity.php">Security</a></li>
            
        </ul>
      </li>
        
        
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" style="color: white" href="#">Modify
        <span class="caret"></span></a>
    
        <ul class="dropdown-menu">
            <li><a href="modifystud.php"><b>Student</b></a></li>
          <li><a href="modifyperm.php">Permission</a></li>
            
        </ul>
   
      </li>
      
        
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">View
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
            <li><a href="viewstud.php">Student</a></li>
          <li><a href="viewsecurity.php">Security</a></li>
            <li><a href="viewwarden.php">Warden</a></li>
        </ul>
      </li>
        
       
        
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Student Status
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="wnormalreg.php">Normal Register</a></li>
          <li><a href="wlatereg.php">Late Register</a></li>
          
        </ul>
      </li>
        
    </ul>

	

    <ul class="nav navbar-nav navbar-right">
	<p class="navbar-text"><span class="glyphicon glyphicon-user"></span> 
      <?php 
          $id=$_SESSION['loginw'];
          $sql= "SELECT Name FROM Warden WHERE '$id'=WardenID";
          $result = $conn->query($sql);
          $row=$result->fetch_assoc();
          echo $row["Name"]; ?></p>
      <li><a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
    </ul>
  </div>
</nav>


  <div class="bod">
<div class="container">
<div class="row">
<div class="col-md-3 row-height">
<div class="clearfix">
<form class ="flef" action="modifystud.php" method="POST" enctype="multipart/form-data">
  
  <div class="uname">
      <label><b><p>Roll No</p></b></label>
    <input type="text" placeholder="Enter RollNo" name="roll" required>
  </div>
  <div class="Go">
  <button type="submit" value="Submit" name="sign">Go</button>
  </div>
   </form>
   </div>
    </div>
    
    <div class="col-md-9">
        <div class="row">

          <?php 
          function fetchdata(){
$servername = "localhost";
$user = "root";
$pass = "password";
$dbname="LHdb";

$conn = new mysqli($servername,$user,$pass,$dbname);

//echo "yo";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$roll=$_POST["roll"];
$s1="select * from Student where RollNo='$roll'";
$result= $conn->query($s1);
if($result->num_rows > 0)
{
  while($row= $result->fetch_assoc())
  {
    $name= $row["Name"];
    
    $addr= $row["HomeAddr"];
    $room= $row["RoomNo"];
    $phone= $row["PhoneNo"];
    $block= $row["BlockNo"];
    $pno = $row["ParentsNo"]; 

//echo $name;
  }
}
?>

<div id="container">
  

 <h1>Modify student details</h1><br>
    <form action="malini/modify_student.php" method="POST" enctype="multipart/form-data">
    
      <pre><span class="inner-pre" style="font-size:20px; font-family:monospace; ">
  <b>     Name           <input name="name" type="text" value='<?php echo  $name; ?>'/><br><br>
       Roll No        <input type="text" name="roll" value="<?php echo  $roll; ?>"/ readonly><br><br>
       Address        <input name="adr" type="text" value='<?php echo  $addr; ?>'/><br><br>
       Mobile Number  <input name="mobile" type="text" value='<?php echo  $phone; ?>'/><br><br>
       Parent Number  <input name="parent" type="text" value='<?php echo  $pno; ?>'/><br><br>  
       RoomNo         <input name="roomno" type="text" value='<?php echo  $room; ?>'/><br><br>
       Block          <input name="block" type="text" value='<?php echo  $block; ?>'/><br><br>
</b>
                      <br>                      <input class="right" type="submit" name="save" value="Save Data" size="25px">
                
               </span> </pre> </form>
  <!--<p>A navigation bar is a navigation header that is placed at the top of the page.</p> -->
</div> 
<?php
$conn->close();
}

if(isset($_POST['sign']))
{
   fetchdata();
} 
?>

</div>
    </div>
</div>
</div>
</div>
    
</body>
</html>
